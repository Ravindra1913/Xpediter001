package org.netcracker.hackathon.trial01;

import com.jcraft.jsch.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

public class XpediterLoginServlet extends HttpServlet {

    public static final Logger log = LoggerFactory.getLogger(XpediterLoginServlet.class);

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter pw = res.getWriter();

        //Collect user login info
        log.error("User trying to Login");
        String userName = req.getParameter("username");
        String password = req.getParameter("password");
        String host = req.getParameter("host");
        int port = Integer.parseInt(req.getParameter("port"));

        //Disconnect any previously existing session
        /*if(SessionManager.getSession() != null) {
            SessionManager.terminateSession(SessionManager.getSession());
        }*/

        //Create a session
        Session session = SessionManager.getNewSession(userName, password, host, port);
        System.out.println("Is session Connected ? = "+session);

        if(session == null){
            //Invalid login info, Go back to login page
            req.getRequestDispatcher("/solutions/tools/XpediterLogin.jsp").forward(req, res);
            pw.println("<p>Invalid Credentials!!!</p>");
        }
        else {
            HttpSession httpSession = req.getSession();
            httpSession.setAttribute("session", session);
            httpSession.setMaxInactiveInterval(600);
            //Valid credentials. Go to Home page/Command execution page.
            req.getRequestDispatcher("/solutions/tools/Xpediter.jsp").forward(req, res);
        }
    }
}
