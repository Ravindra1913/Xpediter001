package org.netcracker.hackathon.trial01;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;


public class CommandExecutionServlet extends HttpServlet {

    public static final Logger log = LoggerFactory.getLogger(CommandExecutionServlet.class);

    public void init() {

    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        log.error("doGet Method of CommandExecutionServlet Entered");
        String command = req.getParameter("command") + " ";
        System.out.println("Command : "+command);

        HttpSession httpSession = req.getSession(false);
        Session session = (Session) httpSession.getAttribute("session");

        //if session == null, previous session expired or session not created yet.
        //this should be handled either by silently creating a new session with required details or redirect the user to the login page to create a new session.
        //this could be handled here or in SessionManager.getSession() method.

        System.out.println("Is session Connected= "+session);

        //Value from Choose Directory in UI
        String gotodir = req.getParameter("currdir");

        System.out.println("gotodir : "+gotodir);

        //To show only the last lines of a command result
        String lastlines = " | tail -n ";

        //Count of lines to be shown
        String countOfLines = "100";
        String recursiveGrep = "grep -r ";


        //Create command using goto directory and execute
        String preparedCommand = prepareCommand(recursiveGrep, command, gotodir, lastlines, countOfLines);

        //Execute the command and get result
        String result = executeCommand(session, preparedCommand);

        //handle the result to seperate each line as an object - yet to be added

        //Value to be set as Choose Directory in UI
        req.setAttribute("workingDirectory", gotodir);

        //Result of commmand execution to be displayed in UI
        req.setAttribute("executionresult", result);

        //Redirect the page to JSP
        req.getRequestDispatcher("/solutions/tools/Xpediter.jsp").forward(req, resp);

    }

    public void doPost(HttpServletRequest req, HttpServletResponse res) {
        res.setContentType("text/html");
        PrintWriter pw = null;
        try {
            pw = res.getWriter();
        } catch (IOException e) {
        }

        HttpSession httpSession = req.getSession();
        Session session = (Session) httpSession.getAttribute("session");


        //Disconnect any previously existing session
        if(session != null) {
            SessionManager.terminateSession(session);
        }

        try {
            req.getRequestDispatcher("/solutions/tools/XpediterLogin.jsp").forward(req, res);
        } catch (ServletException | IOException e) {
        }
        pw.println("<p>Logged Out successfully!!!</p>");
    }

    private String prepareCommand(String recursiveGrep, String keyword, String directorypath, String lastlines, String countOfLines) {
        StringBuilder command = new StringBuilder();
        command.append(recursiveGrep).append(keyword).append(directorypath).append(lastlines).append(countOfLines);

        System.out.println("Prepared Command : "+command);
        return command.toString();
    }


    public Channel createChannel(Session session) throws JSchException, IOException, InterruptedException {
        log.error("Started creating new session");
        ChannelExec channel = null;
        try {
            channel = (ChannelExec) session.openChannel("exec");
            log.error("New Channel created successfully!!!");
        } catch (Exception e) {
            System.out.println("Error : " + e);
        }
        return channel;
    }

    public String executeCommand(Session session, String command) {
        log.error("Executing session = {}, command {}", session, command);
        System.out.println("Executing Command : "+command);
        ChannelExec channel = null;
        try{
            try {
                channel = (ChannelExec) ChannelManager.createExecChannel(session);
            } catch (JSchException | InterruptedException e) {
                System.out.println("Error while creating  new exec channel : " + e);
            }

            channel.setCommand(command);

            // Connect and execute the command
            channel.connect();

            System.out.println("Channel status : " + channel.isConnected());
            /*while (channel.isConnected()) {
                Thread.sleep(200);
            }*/

            // Read and get the output of command execution
            String result = readInputStream(channel);
            //System.out.println("Result : "+result);


            // If wrong command is entered and executed, the resulting error response should be handled and appropriately displayed in UI. Yet to implemented
           /* InputStream errorStream = channel.getErrStream();
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(errorStream));
            String line;
            while ((line = errorReader.readLine()) != null) {
                System.out.println("Standard Error: " + line);
            }*/

            System.out.println("Result of command Execution.");
            log.error("Command Execution completed");
            return result;
        } catch (JSchException | IOException e) {
            log.error("Error during command execution : ", e);
            System.out.println("Error while command execution");
            return "Error while command execution";
        }
        finally{
            //Terminate the channel at the end of command execution.
            ChannelManager.terminateChannel(channel);
            log.error("Channel terminated successfully");
            System.out.println("Channel terminated successfully");
        }
    }

    private static String readInputStream(Channel channel) throws IOException {
        log.error("Started reading Input Stream");
        System.out.println("Started reading Input Stream");

        // Get the input stream associated with standard output
        InputStream inputStream = channel.getInputStream();

        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line).append("#############").append("\n");
            }
        }
        log.error("End of reading Input Stream");
        System.out.println("End of reading Input Stream");
        return result.toString();
    }


}
