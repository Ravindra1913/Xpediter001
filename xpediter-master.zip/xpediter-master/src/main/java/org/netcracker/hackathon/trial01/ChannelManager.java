package org.netcracker.hackathon.trial01;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ChannelManager {

    public static final Logger log = LoggerFactory.getLogger(ChannelManager.class);

    private static ChannelExec channelExec = null;
    private static ChannelSftp channelSftp = null;
    //private static Session session = SessionManager.getSession();

    public static Channel createExecChannel(Session session) throws JSchException, IOException, InterruptedException {
        //A new channel is required & created for every command execution and should be terminated at the end of command execution.
        log.error("Started creating new channel");
        try {
            //handling of session = null should be added
            channelExec = (ChannelExec) session.openChannel("exec");

            log.error("New Channel created successfully!!!");
            //channel.connect();
        } catch (Exception e) {
            System.out.println("Error : " + e);
        }
        return channelExec;

    }

    public static Channel createSftpChannel(Session session) throws JSchException, IOException, InterruptedException {
        log.error("Started creating new Channel");
        try {
            channelSftp = (ChannelSftp) session.openChannel("sftp");

            log.error("New SFTP Channel created successfully!!!");
        } catch (Exception e) {
            log.error("Error while creating a Channel: ", e);
            System.out.println("Error : " + e);
        }
        return channelSftp;
    }

    public static Channel getChannelExec(){
        return channelExec;
    }
    public static Channel getChannelSftp() {
        return channelSftp;
    }

    public static void terminateChannel(Channel channel) {
        if (channel != null) {
            channel.disconnect();
            log.error("Channel terminated");
        }
    }
}
