package org.netcracker.hackathon.trial01;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SessionManager {

    public static final Logger log = LoggerFactory.getLogger(SessionManager.class);


    private static Session session = null;

    public static Session getNewSession(String userName, String password, String host, int port){
        Session session = null;
        try {
            session = new JSch().getSession(userName, host, port);
        } catch (JSchException e) {
            log.error("Error while creating SSH Session : ", e);
            return null;
        }
        session.setPassword(password);
        java.util.Properties config = new java.util.Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config);
        try {
            session.connect();
        } catch (JSchException e) {
            log.error("Unable to create an SSH Connection to Server :", e);
            return null;
        }
        log.error("New SSH Conection to Server created successfully.");
        return session;
    }

    public static Session getSession() {
        System.out.println("Session is : " +session);
        log.error("Retrieving existing SSH Session");
        if(session != null && session.isConnected()) {
            return session;
        }
        else {
            System.out.println("Session is null");
            log.error("Session expired!! Relogin");
            return null;
        }
    }

    public static void terminateSession(Session session) {
        if (session != null) {
            log.error("Session terminated");
            session.disconnect();
        }
    }


}
