package org.netcracker.hackathon.trial01;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class MainDevTest {

    public static void main(String args[]) {
        CommandExecutionServlet t = new CommandExecutionServlet();
        DirectoryNavigationServlet d = new DirectoryNavigationServlet();

        String username = "raka0719";//Input the username - Ex: raka0719
        String host = "devsp075cn";//Enter Hostname - Ex: devsp075cn
        String password = "Sep@2023";//Enter Password
        int port = 22;
        String sshCommand = "grep -r \"xpediter\" /u02/netcracker/toms/u221_ws4_6830/logs";//Enter ssh command to execute - Ex: pwd
        sshCommand = "pwd";

        try {
            Session session = SessionManager.getNewSession(username, password, host, port);
            String directory = d.navigateToDir("/u02/netcracker/toms/u221_ws4_6830/logs", session);
            System.out.println("Directory : "+directory);

            t.executeCommand(session,sshCommand);

        } catch (Exception e) {
            System.out.println("Error while command execution : " + e);
        }
    }
}
