package org.netcracker.hackathon.trial01;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class DirectoryNavigationServlet extends HttpServlet {

    public static final Logger log = LoggerFactory.getLogger(DirectoryNavigationServlet.class);


    public void doGet(HttpServletRequest req, HttpServletResponse res) {
        log.error("doGet Method of DirectoryNavigationServlet Entered");

        Session session = SessionManager.getSession();
        String prevDir = getCurrentDirectory(session);

        String gotodir = req.getParameter("currdir");
        System.out.println("gotodir : "+gotodir);

        String pwd = navigateToDir(gotodir, session);

        System.out.println("Present Wroking Directory: "+pwd);
        if(pwd.equals("Error")){
            pwd = prevDir;
        }
        req.setAttribute("workingDirectory", pwd);
        try {
            req.getRequestDispatcher("/solutions/tools/Xpediter.jsp").forward(req, res);
        } catch (ServletException | IOException e) {

            log.error("Error during Directory Navigation : ", e);
            System.out.println("Error during navigation: "+e);
            SessionManager.terminateSession(session);
        }
        //SessionManager.terminateSession(session);
    }

    public String navigateToDir(String gotodir, Session session) {
        log.error("Navigating to Directory : {} with session : {}", gotodir, session);
        String pwd = "Error";
        ChannelSftp channel = null;
        try {
            channel = (ChannelSftp) ChannelManager.createSftpChannel(session);

            //connect and execute
            channel.connect();

            //Change the current directory to the new one
            channel.cd(gotodir);
            pwd = channel.pwd();

            System.out.println("Successfully navigated to : "+pwd);
            log.error("Successfully navigated to : {}", pwd);

            ChannelManager.terminateChannel(channel);
        } catch (JSchException | IOException | InterruptedException | SftpException e) {
            System.out.println("Error during directory navigation: "+e);
            log.error("Error while Navigating to the new directory : ", e);
            ChannelManager.terminateChannel(channel);
            return pwd;
        }
        return pwd;
    }

    public String getCurrentDirectory(Session session){
        log.error("Getting current directory with session : {}", session);
        ChannelSftp channel = null;
        String pwd = null;
        try {
            channel = (ChannelSftp) ChannelManager.createSftpChannel(session);
            channel.connect();
            pwd = channel.pwd();

        } catch (JSchException | IOException | InterruptedException | SftpException e) {
            log.error("Error while finding current directory :", e);
        }

        System.out.println("Current Directory :"+pwd);
        log.error("Current Directory is : {}", pwd);
        return pwd;
    }
}
